<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> — <?php echo e(config('app.name', 'Escalora')); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Syne:wght@600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="dash-body">
    <?php
        $user = auth()->user();
        $isAdmin = $user?->isAdmin();
    ?>

    <div class="dash-shell">
        <aside class="dash-sidebar">
            <a href="<?php echo e($isAdmin ? route('admin.dashboard') : route('agent.dashboard')); ?>" class="dash-brand">
                <span class="brand-mark">E</span>
                <span>Escalora</span>
            </a>

            <nav class="dash-nav" aria-label="Dashboard">
                <?php echo $__env->yieldContent('sidebar'); ?>
            </nav>

            <div class="dash-sidebar-foot">
                <strong><?php echo e($user?->name); ?></strong>
                <span><?php echo e($user?->company?->name); ?> · <?php echo e($isAdmin ? 'Admin' : 'Agent'); ?></span>
            </div>
        </aside>

        <div class="dash-main">
            <header class="dash-topbar">
                <div style="display:flex;align-items:center;gap:0.75rem;">
                    <button class="dash-menu-btn" type="button" data-dash-menu aria-label="Open menu">☰</button>
                    <h1><?php echo $__env->yieldContent('heading', 'Dashboard'); ?></h1>
                </div>
                <div class="dash-top-actions">
                    <?php echo $__env->yieldContent('actions'); ?>
                    <form method="POST" action="<?php echo e($isAdmin ? route('logout') : route('agent.logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-ghost btn-sm" type="submit">Logout</button>
                    </form>
                </div>
            </header>

            <div class="dash-content">
                <?php if(session('status')): ?>
                    <div class="alert alert-success"><?php echo e(session('status')); ?></div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-error">
                        <strong>Something needs attention:</strong>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>

    <div class="dash-mobile-nav" data-mobile-nav>
        <div class="dash-mobile-panel">
            <a href="<?php echo e($isAdmin ? route('admin.dashboard') : route('agent.dashboard')); ?>" class="dash-brand">
                <span class="brand-mark">E</span>
                <span>Escalora</span>
            </a>
            <nav class="dash-nav">
                <?php echo $__env->yieldContent('sidebar'); ?>
            </nav>
            <button class="btn btn-ghost" type="button" data-close-menu>Close</button>
        </div>
    </div>

    <script src="<?php echo e(asset('js/dashboard.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /Users/ahmed/Desktop/Web_Projects/customer_service/resources/views/layouts/dashboard.blade.php ENDPATH**/ ?>