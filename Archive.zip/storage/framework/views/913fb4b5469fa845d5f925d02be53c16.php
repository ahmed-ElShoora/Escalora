<?php $__env->startSection('title', 'Admin Register'); ?>
<?php $__env->startSection('meta_description', 'Create an Escalora admin account for your company and verify your email to access the dashboard.'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <section class="auth-shell">
        <div class="container auth-grid">
            <aside class="auth-aside reveal">
                <div>
                    <p class="eyebrow">Admin registration</p>
                    <h1>Create your company admin account</h1>
                    <p>
                        Register with your company details, verify your email, then create workspaces and invite agents.
                    </p>
                </div>

                <ul class="auth-points">
                    <li>One admin company workspace hub</li>
                    <li>Invite-only agent onboarding</li>
                    <li>Email verification required before dashboard access</li>
                </ul>
            </aside>

            <div class="auth-panel reveal">
                <h2>Create admin account</h2>
                <p class="lead">Agents cannot self-register. Invite them after setup.</p>

                <?php if($errors->any()): ?>
                    <div class="alert alert-error">
                        <strong>Please review your details:</strong>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form class="form-stack" method="POST" action="<?php echo e(route('register.store')); ?>" data-auth-form>
                    <?php echo csrf_field(); ?>

                    <div class="field">
                        <label for="name">Full name</label>
                        <input id="name" name="name" type="text" value="<?php echo e(old('name')); ?>" required autocomplete="name">
                    </div>

                    <div class="field">
                        <label for="company">Company name</label>
                        <input id="company" name="company" type="text" value="<?php echo e(old('company')); ?>" required autocomplete="organization">
                    </div>

                    <div class="field">
                        <label for="email">Work email</label>
                        <input id="email" name="email" type="email" value="<?php echo e(old('email')); ?>" required autocomplete="username">
                    </div>

                    <div class="form-row two">
                        <div class="field">
                            <label for="password">Password</label>
                            <input id="password" name="password" type="password" required autocomplete="new-password">
                        </div>
                        <div class="field">
                            <label for="password_confirmation">Confirm password</label>
                            <input id="password_confirmation" name="password_confirmation" type="password" required autocomplete="new-password">
                        </div>
                    </div>

                    <button class="btn btn-primary btn-block" type="submit">Create admin account</button>
                </form>

                <p class="auth-switch">
                    Already registered?
                    <a href="<?php echo e(route('login')); ?>">Sign in</a>
                </p>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/auth.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ahmed/Desktop/Web_Projects/customer_service/resources/views/auth/register.blade.php ENDPATH**/ ?>