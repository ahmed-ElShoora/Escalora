<?php $__env->startSection('title', 'Agent Login'); ?>
<?php $__env->startSection('meta_description', 'Sign in to Escalora as an invited support agent.'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <section class="auth-shell">
        <div class="container auth-grid">
            <aside class="auth-aside reveal">
                <div>
                    <p class="eyebrow">Agent access</p>
                    <h1>Sign in to your assigned workspace</h1>
                    <p>
                        Agents join Escalora by invitation only. Use the email and password you set when activating your account.
                    </p>
                </div>

                <ul class="auth-points">
                    <li>No public agent registration</li>
                    <li>Access limited to your workspace</li>
                    <li>Activate via the invite email first</li>
                </ul>
            </aside>

            <div class="auth-panel reveal">
                <h2>Agent login</h2>
                <p class="lead">Enter the credentials from your invitation activation.</p>

                <?php if(session('status')): ?>
                    <div class="alert alert-success"><?php echo e(session('status')); ?></div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-error">
                        <strong>Unable to sign in:</strong>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form class="form-stack" method="POST" action="<?php echo e(route('agent.login.store')); ?>" data-auth-form>
                    <?php echo csrf_field(); ?>

                    <div class="field">
                        <label for="email">Work email</label>
                        <input id="email" name="email" type="email" value="<?php echo e(old('email')); ?>" required autocomplete="username">
                    </div>

                    <div class="field">
                        <label for="password">Password</label>
                        <input id="password" name="password" type="password" required autocomplete="current-password">
                    </div>

                    <label class="remember-row">
                        <input type="checkbox" name="remember" value="1" <?php if(old('remember')): echo 'checked'; endif; ?>>
                        <span>Remember me</span>
                    </label>

                    <button class="btn btn-primary btn-block" type="submit">Sign in</button>
                </form>

                <p class="auth-switch">
                    Company admin?
                    <a href="<?php echo e(route('login')); ?>">Go to admin login</a>
                </p>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/auth.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ahmed/Desktop/Web_Projects/customer_service/resources/views/auth/agent-login.blade.php ENDPATH**/ ?>