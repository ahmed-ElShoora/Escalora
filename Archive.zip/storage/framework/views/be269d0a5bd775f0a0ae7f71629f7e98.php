<?php echo e($slot); ?>

<?php /**PATH /Users/ahmed/Desktop/Web_Projects/customer_service/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>