<?php $__env->startSection('title', 'Admin Dashboard'); ?>
<?php $__env->startSection('heading', 'Overview'); ?>

<?php $__env->startSection('sidebar'); ?>
    <a href="<?php echo e(route('admin.dashboard')); ?>" class="is-active">Overview</a>
    <a href="<?php echo e(route('admin.workspaces.index')); ?>">Workspaces</a>
    <a href="<?php echo e(route('admin.agents.index')); ?>">Agents</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('actions'); ?>
    <a href="<?php echo e(route('admin.workspaces.create')); ?>" class="btn btn-primary btn-sm">New workspace</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-intro">
        <p>Welcome back, <?php echo e($admin->name); ?>. Manage <?php echo e($admin->company?->name); ?> workspaces and agents from one place.</p>
    </div>

    <div class="stats-grid">
        <article class="stat-card">
            <span>Workspaces</span>
            <strong><?php echo e($workspaceCount); ?></strong>
        </article>
        <article class="stat-card">
            <span>Total agents</span>
            <strong><?php echo e($agentCount); ?></strong>
        </article>
        <article class="stat-card">
            <span>Active agents</span>
            <strong><?php echo e($activeAgents); ?></strong>
        </article>
        <article class="stat-card">
            <span>Pending invites</span>
            <strong><?php echo e($pendingInvites); ?></strong>
        </article>
    </div>

    <section class="panel-card">
        <div class="panel-head">
            <h2>Recent workspaces</h2>
            <a href="<?php echo e(route('admin.workspaces.index')); ?>" class="btn btn-ghost btn-sm">View all</a>
        </div>

        <?php if($recentWorkspaces->isEmpty()): ?>
            <div class="empty-state">
                <strong>No workspaces yet</strong>
                <p>Create your first company workspace to start inviting agents.</p>
                <a href="<?php echo e(route('admin.workspaces.create')); ?>" class="btn btn-primary" style="margin-top:1rem;">Create workspace</a>
            </div>
        <?php else: ?>
            <div class="table-wrap">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Agents</th>
                            <th>Created</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $recentWorkspaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workspace): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($workspace->name); ?></td>
                                <td><?php echo e($workspace->agents_count); ?></td>
                                <td><?php echo e($workspace->created_at?->format('M j, Y')); ?></td>
                                <td><a href="<?php echo e(route('admin.workspaces.show', $workspace)); ?>" class="btn btn-ghost btn-sm">Open</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ahmed/Desktop/Web_Projects/customer_service/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>