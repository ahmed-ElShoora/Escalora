<?php $__env->startSection('title', 'Agent Dashboard'); ?>
<?php $__env->startSection('heading', 'Live support'); ?>

<?php $__env->startSection('sidebar'); ?>
    <a href="<?php echo e(route('agent.dashboard')); ?>" class="is-active">Live support</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('actions'); ?>
    <label class="agent-presence-toggle">
        <input type="checkbox" data-agent-presence <?php if($agent->is_available): echo 'checked'; endif; ?>>
        <span data-presence-label><?php echo e($agent->isOnline() ? 'Online' : 'Go online'); ?></span>
    </label>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div
        class="agent-chat-layout"
        data-agent-chat
        data-inbox-url="<?php echo e(route('agent.conversations.index')); ?>"
        data-presence-url="<?php echo e(route('agent.presence.update')); ?>"
        data-messages-url-template="<?php echo e(route('agent.conversations.messages', '__CONVERSATION__')); ?>"
        data-send-url-template="<?php echo e(route('agent.conversations.send', '__CONVERSATION__')); ?>"
        data-close-url-template="<?php echo e(route('agent.conversations.close', '__CONVERSATION__')); ?>"
        data-broadcast-auth-url="<?php echo e(route('support.broadcasting.auth')); ?>"
        data-pusher-key="<?php echo e(config('broadcasting.connections.pusher.key')); ?>"
        data-pusher-cluster="<?php echo e(config('broadcasting.connections.pusher.options.cluster')); ?>"
        data-workspace-id="<?php echo e($workspace?->id); ?>"
        data-agent-id="<?php echo e($agent->id); ?>"
    >
        <section class="panel-card">
            <div class="panel-head">
                <div>
                    <h2>My conversations</h2>
                    <p class="panel-subtitle">Chats assigned to you update automatically.</p>
                </div>
            </div>
            <p class="queue-note" data-queue-note><?php echo e($waitingCount); ?> waiting in your workspace queue</p>
            <div class="agent-conversation-list" data-conversation-list>
                <?php $__empty_1 = true; $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <button class="agent-conversation-item" type="button" data-conversation-id="<?php echo e($conversation->id); ?>" data-customer-name="<?php echo e($conversation->customer_name); ?>">
                        <strong><?php echo e($conversation->customer_name); ?></strong>
                        <span>Started <?php echo e($conversation->created_at?->diffForHumans()); ?></span>
                    </button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="empty-state" data-empty-conversations>No active chats. Go online to receive new conversations.</p>
                <?php endif; ?>
            </div>
        </section>

        <section class="panel-card" data-agent-chat-panel>
            <div class="panel-head">
                <div>
                    <h2 data-selected-customer>Select a conversation</h2>
                    <p class="panel-subtitle" data-agent-count>Checking workspace presence…</p>
                </div>
                <button class="btn btn-danger btn-sm" type="button" data-close-conversation hidden>End chat</button>
            </div>
            <div class="agent-chat-messages" data-agent-messages aria-live="polite">
                <div class="empty-state" data-agent-chat-empty>Select a customer to read and reply to their messages.</div>
            </div>
            <form class="agent-chat-composer" data-agent-reply-form hidden>
                <label class="sr-only" for="agent-reply">Reply to customer</label>
                <textarea id="agent-reply" name="message" rows="2" maxlength="5000" placeholder="Write a reply..." required></textarea>
                <button class="btn btn-primary" type="submit">Send</button>
            </form>
            <div class="alert alert-error" data-agent-error hidden></div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://js.pusher.com/8.4.0/pusher.min.js"></script>
    <script src="<?php echo e(asset('js/agent-chat.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ahmed/Desktop/Web_Projects/customer_service/resources/views/agent/dashboard.blade.php ENDPATH**/ ?>