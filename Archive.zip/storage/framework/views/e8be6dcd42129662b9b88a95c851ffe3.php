<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/ahmed/Desktop/Web_Projects/customer_service/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>