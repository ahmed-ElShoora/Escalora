<?php $__env->startSection('title', 'Verify Email'); ?>
<?php $__env->startSection('meta_description', 'Verify your Escalora admin email to access the dashboard.'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <section class="auth-shell">
        <div class="container" style="max-width: 640px;">
            <div class="auth-panel reveal">
                <h2>Verify your email</h2>
                <p class="lead">
                    We sent a verification link to <strong><?php echo e(auth()->user()->email); ?></strong>.
                    Open it to unlock your admin dashboard.
                </p>

                <?php if(session('status')): ?>
                    <div class="alert alert-success"><?php echo e(session('status')); ?></div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('verification.send')); ?>" class="form-stack" data-auth-form>
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-primary btn-block" type="submit">Resend verification email</button>
                </form>

                <form method="POST" action="<?php echo e(route('logout')); ?>" style="margin-top: 1rem;">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-ghost btn-block" type="submit">Sign out</button>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/auth.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ahmed/Desktop/Web_Projects/customer_service/resources/views/auth/verify-email.blade.php ENDPATH**/ ?>