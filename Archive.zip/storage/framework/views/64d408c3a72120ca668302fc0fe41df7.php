<?php $__env->startSection('title', 'Create Workspace'); ?>
<?php $__env->startSection('heading', 'Create workspace'); ?>

<?php $__env->startSection('sidebar'); ?>
    <a href="<?php echo e(route('admin.dashboard')); ?>">Overview</a>
    <a href="<?php echo e(route('admin.workspaces.index')); ?>" class="is-active">Workspaces</a>
    <a href="<?php echo e(route('admin.agents.index')); ?>">Agents</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="panel-card" style="max-width:640px;">
        <form method="POST" action="<?php echo e(route('admin.workspaces.store')); ?>" class="form-stack">
            <?php echo csrf_field(); ?>

            <div class="field">
                <label for="name">Workspace name</label>
                <input id="name" name="name" type="text" value="<?php echo e(old('name')); ?>" required>
            </div>

            <div class="field">
                <label for="description">Description</label>
                <textarea id="description" name="description"><?php echo e(old('description')); ?></textarea>
            </div>

            <div class="inline-actions">
                <button class="btn btn-primary" type="submit">Create workspace</button>
                <a href="<?php echo e(route('admin.workspaces.index')); ?>" class="btn btn-ghost">Cancel</a>
            </div>
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ahmed/Desktop/Web_Projects/customer_service/resources/views/admin/workspaces/create.blade.php ENDPATH**/ ?>