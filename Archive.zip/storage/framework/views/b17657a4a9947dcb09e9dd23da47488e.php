<?php $__env->startSection('title', 'Agents'); ?>
<?php $__env->startSection('heading', 'All agents'); ?>

<?php $__env->startSection('sidebar'); ?>
    <a href="<?php echo e(route('admin.dashboard')); ?>">Overview</a>
    <a href="<?php echo e(route('admin.workspaces.index')); ?>">Workspaces</a>
    <a href="<?php echo e(route('admin.agents.index')); ?>" class="is-active">Agents</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-intro">
        <p>Company-wide agent list across every workspace you own.</p>
    </div>

    <section class="panel-card">
        <?php if($agents->isEmpty()): ?>
            <div class="empty-state">
                <strong>No agents yet</strong>
                <p>Open a workspace and send an invitation to get started.</p>
            </div>
        <?php else: ?>
            <div class="table-wrap">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Workspace</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($agent->name); ?></td>
                                <td><?php echo e($agent->email); ?></td>
                                <td>
                                    <?php if($agent->workspace): ?>
                                        <a href="<?php echo e(route('admin.workspaces.show', $agent->workspace)); ?>"><?php echo e($agent->workspace->name); ?></a>
                                    <?php else: ?>
                                        —
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="status-pill <?php echo e($agent->isActive() ? 'active' : 'pending'); ?>">
                                        <?php echo e($agent->isActive() ? 'Active' : 'Pending Invitation'); ?>

                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div style="margin-top:1rem;"><?php echo e($agents->links()); ?></div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ahmed/Desktop/Web_Projects/customer_service/resources/views/admin/agents/index.blade.php ENDPATH**/ ?>