<?php $__env->startSection('title', 'Activate Agent Account'); ?>
<?php $__env->startSection('meta_description', 'Activate your Escalora agent invitation and set your password.'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <section class="auth-shell">
        <div class="container auth-grid">
            <aside class="auth-aside reveal">
                <div>
                    <p class="eyebrow">Invitation</p>
                    <h1>Activate your agent account</h1>
                    <p>
                        Hi <?php echo e($agent->name); ?>. Set a secure password to join
                        <strong><?php echo e($agent->company?->name); ?></strong>
                        in the
                        <strong><?php echo e($agent->workspace?->name); ?></strong>
                        workspace.
                    </p>
                </div>
            </aside>

            <div class="auth-panel reveal">
                <h2>Set your password</h2>
                <p class="lead">After activation you can sign in anytime from the agent login page.</p>

                <?php if($errors->any()): ?>
                    <div class="alert alert-error">
                        <strong>Unable to activate:</strong>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form class="form-stack" method="POST" action="<?php echo e(route('agent.invitation.store', $token)); ?>" data-auth-form>
                    <?php echo csrf_field(); ?>

                    <div class="field">
                        <label for="email">Email</label>
                        <input id="email" type="email" value="<?php echo e($agent->email); ?>" disabled>
                    </div>

                    <div class="form-row two">
                        <div class="field">
                            <label for="password">Password</label>
                            <input id="password" name="password" type="password" required autocomplete="new-password">
                        </div>
                        <div class="field">
                            <label for="password_confirmation">Confirm password</label>
                            <input id="password_confirmation" name="password_confirmation" type="password" required autocomplete="new-password">
                        </div>
                    </div>

                    <button class="btn btn-primary btn-block" type="submit">Activate account</button>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/auth.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ahmed/Desktop/Web_Projects/customer_service/resources/views/auth/activate-agent.blade.php ENDPATH**/ ?>