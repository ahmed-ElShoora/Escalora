<?php $__env->startSection('title', 'Workspaces'); ?>
<?php $__env->startSection('heading', 'Workspaces'); ?>

<?php $__env->startSection('sidebar'); ?>
    <a href="<?php echo e(route('admin.dashboard')); ?>">Overview</a>
    <a href="<?php echo e(route('admin.workspaces.index')); ?>" class="is-active">Workspaces</a>
    <a href="<?php echo e(route('admin.agents.index')); ?>">Agents</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('actions'); ?>
    <a href="<?php echo e(route('admin.workspaces.create')); ?>" class="btn btn-primary btn-sm">New workspace</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-intro">
        <p>Each workspace keeps its own agents and data isolated inside your company.</p>
    </div>

    <section class="panel-card">
        <?php if($workspaces->isEmpty()): ?>
            <div class="empty-state">
                <strong>No workspaces found</strong>
                <p>Create a workspace for a team, brand, or support channel.</p>
            </div>
        <?php else: ?>
            <div class="table-wrap">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Workspace</th>
                            <th>Agents</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $workspaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workspace): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <strong><?php echo e($workspace->name); ?></strong>
                                    <?php if($workspace->description): ?>
                                        <div style="color:var(--muted);font-size:0.85rem;"><?php echo e($workspace->description); ?></div>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($workspace->agents_count); ?></td>
                                <td><?php echo e($workspace->created_at?->format('M j, Y')); ?></td>
                                <td class="inline-actions">
                                    <a href="<?php echo e(route('admin.workspaces.show', $workspace)); ?>" class="btn btn-ghost btn-sm">Manage</a>
                                    <a href="<?php echo e(route('admin.workspaces.edit', $workspace)); ?>" class="btn btn-ghost btn-sm">Edit</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div style="margin-top:1rem;"><?php echo e($workspaces->links()); ?></div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/ahmed/Desktop/Web_Projects/customer_service/resources/views/admin/workspaces/index.blade.php ENDPATH**/ ?>