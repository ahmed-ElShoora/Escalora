<?php
    $current = request()->route()?->getName();
?>

<header class="site-header" data-site-header>
    <div class="container nav-inner">
        <a href="<?php echo e(route('home')); ?>" class="brand" aria-label="Escalora home">
            <span class="brand-mark">E</span>
            <span>Escalora</span>
        </a>

        <nav class="nav-links" aria-label="Primary">
            <a href="<?php echo e(route('home')); ?>" class="<?php echo e($current === 'home' ? 'is-active' : ''); ?>">Home</a>
            <a href="<?php echo e(route('services')); ?>" class="<?php echo e($current === 'services' ? 'is-active' : ''); ?>">Services</a>
            <a href="<?php echo e(route('about')); ?>" class="<?php echo e($current === 'about' ? 'is-active' : ''); ?>">About</a>
            <a href="<?php echo e(route('contact')); ?>" class="<?php echo e($current === 'contact' ? 'is-active' : ''); ?>">Contact</a>
        </nav>

        <div class="nav-actions">
            <a href="<?php echo e(route('login')); ?>" class="btn btn-ghost">Login</a>
            <a href="<?php echo e(route('register')); ?>" class="btn btn-primary">Get Started</a>
        </div>

        <button
            class="nav-toggle"
            type="button"
            aria-label="Toggle menu"
            aria-expanded="false"
            data-nav-toggle
        >
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>

</header>
<?php /**PATH /Users/ahmed/Desktop/Web_Projects/customer_service/resources/views/partials/navbar.blade.php ENDPATH**/ ?>